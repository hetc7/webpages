const navigation = document.querySelector(".navigation");

navigation.addEventListener("click", () => {
  navigation.classList.toggle("active");
});